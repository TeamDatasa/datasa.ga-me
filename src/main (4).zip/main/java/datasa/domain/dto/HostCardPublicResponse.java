package datasa.domain.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class HostCardPublicResponse {
	@JsonProperty("isPublic")
	private boolean isPublic;
}
