package datasa.domain.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(
        name = "TRIP_LOCATION",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uq_trip_location_order",
                        columnNames = {"trip_id", "order_no"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
public class TripLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "trip_location_id")
    private Long tripLocationId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "trip_id", nullable = false)
    private Trip trip;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id", nullable = false)
    private Location location;

    @Column(name = "order_no", nullable = false)
    private Integer orderNo;

    @Column(name = "memo", length = 255)
    private String memo;
}
